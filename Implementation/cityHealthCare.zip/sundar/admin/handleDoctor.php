<?php 
include 'doctor.php';
include '../php/classes/connection.php';
class HandleDoctor extends Connection{

	public function __construct(){
		$this->connect();
	}

	public function add($doctor){
		$r = false;
		$q = "INSERT INTO `doctor`( `firstname`, `lastname`, `speciality`, `avaialbeFrom`, `avaialbeTo`,`price`) VALUES (?,?,?,?,?,?)";
		$qs = $this->conn->prepare($q);
		$qs->bind_param("sssssi",$a,$b,$c,$d,$e,$f);
		
		$a = $doctor->getFirstName();
		$b = $doctor->getLastName();
		$c = $doctor->getSpeciality();
		$d = $doctor->getAvailableFrom();
		$e = $doctor->getAvailableTo();
		$f = $doctor->getPrice();

		$r = $qs->execute();
		$qs->close();
		return $r;
	}

	public function delete($docId){
		$q = "DELETE FROM `doctor` WHERE `id` = ?";
		$qs = $this->conn->prepare($q);
		$qs->bind_param("i",$docId);
		$r = $qs->execute();
		$qs->close();
		return $r;
	}

}

$docHandler = new HandleDoctor();

if ( isset($_POST["btnAddDoctor"]) ) {
	
	if ( isset($_POST["firstname"]) && 
		 isset($_POST["lastname"]) && 
		 isset($_POST["speciality"]) && 
		 isset($_POST["availablefrom"]) && 
		 isset($_POST["availableto"]) &&
		 isset($_POST["price"]) 
		) {

		$firstname = $_POST["firstname"];
		$lastname = $_POST["lastname"];
		$speciality = $_POST["speciality"];
		$availablefrom = $_POST["availablefrom"];
		$availableto = $_POST["availableto"];
		$price = floatval($_POST["price"]);

		$doctor = new Doctor();

		$doctor->setFirstName($firstname);
		$doctor->setLastName($lastname);
		$doctor->setSpeciality($speciality);
		$doctor->setAvailableFrom($availablefrom);
		$doctor->setAvailableTo($availableto);
		$doctor->setPrice($price);

		$rv = "";
		if( $docHandler->add($doctor) ){
			$rv = "Doctor added";
		}else{
			$rv = "Error";
		}

		header("Location: ../index.php?msg=".$rv);

	}

}

if ( isset($_POST["btnDelDoctor"]) ) {
	
	if ( isset($_POST["doctorid"]) ) {
		$doctorid = $_POST["doctorid"];

		$rv = "";
		if( $docHandler->delete($doctorid) ){
			$rv = "Doctor deleted";
		}else{
			$rv = "Error";
		}

		header("Location: ../index.php?msg=".$rv);
	}

}


?>