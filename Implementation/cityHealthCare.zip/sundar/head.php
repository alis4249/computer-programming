<?php 

echo '

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>City Health Care | '.$title.'</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />
<link type="text/css" rel="stylesheet" href="css/jquery.modal.css" />
<link type="icon" rel="icon" href="images/logo.png" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.modal.min.js"></script>
<script type="text/javascript" src="js/msg.js"></script>
';
?>