<?php 
include 'session.php';
include 'php/classes/appointment.php';

$appointment = new Appointment();

if ( isset($_POST["btnBookAppointment"]) ) {

	$returnValue = "";

	if ( isset($_POST["datetime"]) && 
		 isset($_POST["reason"]) && 
		 isset($_POST["doctorid"])
		) {

		$datetime = $_POST["datetime"];
		$reason = $_POST["reason"];
		$doctorid = intval($_POST["doctorid"]);

		if ( strlen($reason) > 0 
			 && $doctorid > 0
			 && strlen($datetime) > 0 
			) {

				$returnValue = $appointment->book($datetime,$reason,$doctorid);

				if ( $returnValue == "ok" ) {
					$returnValue = "Appointment booked.";
				}
				if ( $returnValue == "error" ) {
					$returnValue = "Booking error.";
				}

		}else{
			$returnValue = "Please enter all the fields.";
		}

	}else{
		$returnValue = "No Post values.";
	}

	header("Location: index.php?msg=".$returnValue);
	exit();

}

?>