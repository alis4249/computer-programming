var msgElement = document.createElement("div");
msgElement.id = "message";
msgElement.innerHTML = "<img src='images/info.png'>";

window.onload = function() {
	const messageParam = getUrlParameter('msg');
	if ( messageParam !== "" ) {
		msgElement.innerHTML += messageParam;
		document.body.appendChild(msgElement);
	}

	setTimeout(function(){
		msgElement.style.top = "-100px";
	},5000);

}

function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};