<?php 
include 'admin/doctor.php';
include 'php/classes/connection.php';

class Statics extends Connection{

	public function __construct(){
		$this->connect();
	}

	public function getAllDoctors(){
		$r = "";
		$query = "SELECT * FROM doctor";
		//`id`, `firstname`, `lastname`, `speciality`, `avaialbeFrom`, `avaialbeTo`
		$st = $this->conn->prepare($query);

		if ( $st->execute() ){
			$st->store_result();
			$st->bind_result($id,$firstname,$lastname,$speciality,$avaialbeFrom,$avaialbeTo,$price);

			if ( $st->num_rows < 1 ) {
				$r = "No doctors found.";
			}else{
				$r = array();
				while( $st->fetch() ){
					
					$doctor = new Doctor();
					$doctor->setId($id);
					$doctor->setFirstName($firstname);
					$doctor->setLastName($lastname);
					$doctor->setSpeciality($speciality);
					$doctor->setAvailableFrom($avaialbeFrom);
					$doctor->setAvailableTo($avaialbeTo);
					$doctor->setPrice($price);

					array_push($r,$doctor);

				}
			}

		}else{
			$r = "Error";
		}
		return $r;
	}

	public function getMyAppointments(){
		$r = "";
		$query = "SELECT a.datetime,a.reason,d.price,d.firstname,d.lastname,a.id FROM appointment a,doctor d WHERE d.id = a.doctorid AND a.patientid = ? ORDER BY a.id DESC";
		//`id`, `firstname`, `lastname`, `speciality`, `avaialbeFrom`, `avaialbeTo`
		$st = $this->conn->prepare($query);
		$st->bind_param("i",$_SESSION["userid"]);

		if ( $st->execute() ){
			$st->store_result();
			$st->bind_result($aDateTime,$aReason,$doctorPrice,$firstname,$lastname,$aid);

			if ( $st->num_rows < 1 ) {
				$r = "No appointments found.";
			}else{
				$r = array();
				while( $st->fetch() ){
					$name = $firstname.' '.$lastname;
					array_push($r,array($aDateTime,$aReason,$doctorPrice,$name,$aid));
				}
			}

		}else{
			$r = "Error";
		}
		return $r;
	}

}

$statics = new Statics();

$allDoctors = $statics->getAllDoctors();
$myAppointments = $statics->getMyAppointments();

?>