<?php 
include 'session.php';
include 'statics.php';		
?>
<!DOCTYPE html>
<html>
<head>
	
	<?php 
	$title = "Home";
	include 'head.php';
	?>
</head>
<body>

	<br>
	<div id="nav" class="block">
		<div class="title">
			<img src="images/logo.png">
			<span><a href="index.php">City Health Care</a></span>
		</div>
		<div class="navLinks">
			<?php 
				if ( !$loggedIn ) {
					echo '
					<a href="loginSignup.php#signup">SignUp</a>
					<a href="loginSignup.php">Login</a>
					<a href="usermanual.php">User Manual</a>
					';
				}else{
					echo '
						<a href="logout.php" class="logoutBtn">Logout</a>
						<a href="#appointments" rel="modal:open">My Appointments</a>
					';
				}
			?>
			<a href="index.php#about">About</a>
			<a href="index.php">Home</a>
		</div>
	</div>

	<div id="banner" class="block">
		<img src="images/banner.jpg">
		<?php 
			if ($loggedIn) {
				echo '<span>User Manual 
				<br><small>Hello, '.$_SESSION["username"].'</small></span>';
			}else{
				echo '<span>User Manual</span>';
			}
		?>
	</div>


	<div class="block usermanual">
		<h3 class="tc">Login and Sign Up</h3>
		<h5 class="tc">Patients can login and sign up by clicking login and signup button from navigation menu. </h5>
		<img src="images/manual/login.PNG">
		<img src="images/manual/signup.PNG">
	</div>

	<div class="block usermanual">
		<h3 class="tc">Find Doctors</h3>
		<h5 class="tc">Patients can view list of all doctors and their informations. </h5>
		<img src="images/manual/findDoctors.png">
	</div>

	<div class="block usermanual">
		<h3 class="tc">Appointments</h3>
		<h5 class="tc">Logged in patients can book appointments with desire doctors at desired date time.</h5>
		<img src="images/manual/appointment.png">
	</div>

	<div class="block usermanual">
		<h3 class="tc">View Appointments</h3>
		<h5 class="tc">Logged in patients can view their list of all appoitments.</h5>
		<img src="images/manual/myAppointment.png">
	</div>

</body>

</html>