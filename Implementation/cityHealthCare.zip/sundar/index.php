<?php 
include 'session.php';
include 'statics.php';		
?>
<!DOCTYPE html>
<html>
<head>
	
	<?php 
	$title = "Home";
	include 'head.php';
	?>
</head>
<body>

	<?php 

		if ( is_array($allDoctors) ) {
			echo "<script type='text/javascript'>";
			echo "var allDocs = [];";
			$counter = 0;
			foreach ($allDoctors as $doctor) {
				echo "allDocs[".$counter."] = ['".$doctor->getId()."','".$doctor->getAvailableFrom()."','".$doctor->getAvailableTo()."'];";
				$counter++;
			}
			echo "</script>";
		}

	?>

	<br>
	<div id="nav" class="block">
		<div class="title">
			<img src="images/logo.png">
			<span><a href="index.php">City Health Care</a></span>
		</div>
		<div class="navLinks">
			<?php 
				if ( !$loggedIn ) {
					echo '
					<a href="loginSignup.php#signup">SignUp</a>
					<a href="loginSignup.php">Login</a>
					';
				}else{
					echo '
						<a href="logout.php" class="logoutBtn">Logout</a>
						<a href="#appointments" rel="modal:open">My Appointments</a>
					';
				}
			?>
			<a href="usermanual.php">User Manual</a>
			<a href="index.php#about">About</a>
			<a href="index.php">Home</a>
		</div>
	</div>

	<div id="banner" class="block">
		<img src="images/banner.jpg">
		<?php 
			if ($loggedIn) {
				echo '<span> Hello, '.$_SESSION["username"].'
				<br><small>How can we help you?</small></span>';
			}else{
				echo '<span>Welcome</span>';
			}
		?>
	</div>

	<?php 

		if ( $loggedIn ) {
			if ( $_SESSION["admin"] == true ) {
				echo '

					<div id="adminPanel" class="block tc">
						<h3 class="tc">Admin Panel</h3>
						<hr>
						<a href="#addDoctor" class="btn" rel="modal:open">Add Doctor</a>
						<a href="#deleteDoctor" class="btn" rel="modal:open">Delete Doctor</a>
					</div>

				';
			}
		}

	?>

	<div id="functions" class="block">
		<a href="#appointmentForm" class="function" rel="modal:open">
			<img src="images/appointment.png">
			Appointment</a>
		<a href="#allDocs" class="function" rel="modal:open">
			<img src="images/doctor.png">
			Find a doctor</a>
		<a href="#contact" class="function">
			<img src="images/contact.png">
			Contact Us</a>
	</div>

	<div id="about" class="block">
		<h3 class="tc">About</h3>
		<p class="jst pad">
			As we are living in the era of technology, this day’s people are very modern and technology based. We people do not like stand on long queue and wait for the turn. Everyone use technology like laptop, mobile phone, and internet for taking appointment or heath suggestions with doctor online. <br>
			“City health care website” through the help of this website patient can share their health issue with the doctors in a safe way. Patient can also take health tips from the doctors. They can also know at what time doctors are available at the city health care and as per the schedule, they can take their appointment with the individual doctors. 

		</p>
	</div>

	<form class="form full" id="contact">
		<h3>Contact Us</h3>
		<hr>
		<input type="text" placeholder="Your full name...">
		<input type="text" placeholder="Your email address...">
		<textarea placeholder="Message..." rows="4" style="max-width: 100%;min-width: 100%;"></textarea>
		<button>Send</button>
	</form>

	<!-- modals -->
	<?php 
		if( $loggedIn ){
			if ( $_SESSION["admin"] == true ) {
				echo '
				<div id="addDoctor" class="modal">
				  <form class="form form-modal" action="admin/handleDoctor.php" method="POST">
				  	<h3>Add Doctor</h3><br>
				  	<input type="text" name="firstname" placeholder="Firstname">
				  	<input type="text" name="lastname" placeholder="Lastname">
				  	<input type="text" name="speciality" placeholder="Speciality seperated with comma" title="Othodontist,General Physician,...">
				  	<h5>Available from:</h5>
				  	<input type="datetime-local" name="availablefrom">
				  	<h5>Available to:</h5>
				  	<input type="datetime-local" name="availableto">
				  	<input type="number" name="price" placeholder="Price">
				  	<button type="submit" name="btnAddDoctor">Add</button>
				  </form>
				</div>

				<div id="deleteDoctor" class="modal">
				  <form class="form form-modal" action="admin/handleDoctor.php" method="POST">
				  	<h3>Delete Doctor</h3><br>
				  	<input type="number" name="doctorid" placeholder="Doctor id">
				  	<button type="submit" name="btnDelDoctor">Delete</button>
				  </form>
				</div>
				';
			}
		}
	?>

	<div id="appointmentForm" class="modal">
		<?php

			if ( $loggedIn ) {
				echo '
				<form method="POST" action="appoint.php" class="form form-modal">
					<h5>Doctor</h5>
					<select name="doctorid" id="doctorSelect">
						<option value="0">Choose a doctor you want to be appointed with</option>
						';
						if ( is_array($allDoctors) ) {
							foreach ($allDoctors as $doc) {
								echo '<option value="'.$doc->getId().'">'.$doc->getFirstName().' '.$doc->getLastName().'</option>';
							}
						}
					echo '
					</select>

					<h5>Appointment date time</h5>
					<input type="datetime-local" name="datetime" id="doctorAvailability">

					<textarea placeholder="Reason for booking this appointment..." rows="4" name="reason"></textarea>

					<button name="btnBookAppointment" type="submit">Book appointment</button>
				</form>
				';

				echo '
				<script type="text/javascript">
					$("#doctorSelect").change(function(){
						$.each(allDocs,function(index,value){
							if ( parseInt(value[0]) == parseInt($("#doctorSelect").val())  ) {
								$("#doctorAvailability").attr("min",value[1].replace(/\s+/g, \'T\'));
								$("#doctorAvailability").attr("max",value[2].replace(/\s+/g, \'T\'));
							}
						});
					});
				</script>
				';
			}else{
				echo "Please login.";
			}

		?>
	</div>

	<?php 
		echo '<div id="appointments" class="modal">
		<h5>Your appointments</h5>';
		if ( is_array($myAppointments) ) {
			foreach ($myAppointments as $appointment) {
				$dateTime = $appointment[0];
				echo '
				<div class="doc">
					<div class="fullname tc">#'.$appointment[4].'</div>
					<div class="tc">Appointment date time</div>
					<div class="fullname tc">'.date('Y-m-d h:i A', strtotime($dateTime)).'</div>
					<div class="tc">--------------------</div>
					<div class="fullname tc">Price: &pound;'.$appointment[2].'</div>
					<div class="tc">--------------------</div>
					<div class="tc">Reason:</div>
					<div class="fullname tc">'.$appointment[1].'</div>
					<div class="tc">--------------------</div>
					<div class="fullname tc">Dr. '.$appointment[3].'</div>
				</div>
				';
			}	
		}else{
			echo "<div>".$myAppointments."</div>";
		}
		echo '</div>';
	?>
	

	<div id="allDocs" class="modal">
		

		<?php 

			if ( is_array($allDoctors) ) {
				echo '<h3>Our Doctors ('.count($allDoctors).')</h3><br>';
				foreach ($allDoctors as $doc) {
					echo '
					<div class="doc">
						<div class="fullname tc">Dr. '.$doc->getFirstName().' '.$doc->getLastName().'</div>
						<div class="tc">--------------------</div>
						<div class="speciality tc" onclick="alert(\''.$doc->getSpeciality().'\');">View speciality</div>
						<hr>
						<div class="availablity">
							<span>
								<span>Available from</span>
								<div>'.$doc->getAvailableFrom().'</div>
							</span>
							<span class="r">
								<span>Available to</span>
								<div>'.$doc->getAvailableTo().'</div>
							</span>
						</div>
					</div>
					';
				}
			}else{
				echo "<h3>Our Doctors</h3><br><div class='tc'>".$allDoctors."</div>";
			}

		?>
	</div>

</body>
</html>