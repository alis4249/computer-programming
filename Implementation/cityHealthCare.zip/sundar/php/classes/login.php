<?php 
class Login extends Connection{

	public function __construct(){
		$this->connect();
	}

	public function login($un,$ps){

		$r = "";
		$query = "SELECT * FROM patient WHERE username = ? AND password = ?";
		//`id`, `firstname`, `lastname`, `age`, `sex`, `address`, `phone`, `username`, `password` 
		$st = $this->conn->prepare($query);
		$st->bind_param("ss",$usn,$pss);
		$usn = $un;
		$pss = md5($ps);

		if ( $st->execute() ){
			$st->store_result();
			$st->bind_result($id,$fn,$ln,$age,$sex,$address,$phone,$dbUn,$dbPs);

			if ( $st->num_rows < 1 ) {
				$r = " Username or password is incorrect!";
			}else{
				if( $st->fetch() ){
					
					$_SESSION["userid"] = $id; 
					$_SESSION["username"] = $dbUn;
					$_SESSION["firstName"] = $fn;
					$_SESSION["lastName"] = $ln;
					$_SESSION["address"] = $address;
					$_SESSION["age"] = $age;
					$_SESSION["phone"] = $phone;
					$_SESSION["sex"] = $sex;
					$_SESSION["admin"] = false;

					if ( strtolower($dbUn) == "cityadmin" ) {
						$_SESSION["admin"] = true;
					}

					$r = "success";

				}
			}

		}else{
			$r = "Error";
		}
		return $r;
	}

}


if ( isset($_POST["btnLogin"]) ) {

	$returnValue = "";

	if ( isset($_POST["username"]) && isset($_POST["password"]) ) {

		$un = $_POST["username"];
		$ps = $_POST["password"];

		if ( strlen($un) > 6 && strlen($ps) > 6 ) {
			$loginUser = new Login();
			$returnValue = $loginUser->login($un,$ps);

			if ( $returnValue == "success" ) {
				header("Location: index.php?msg=Logged in");
				exit();
			}

		}else{
			$returnValue = "Ivalid username and password";
		}

	}else{
		$returnValue = "Enter username and password!";
	}

	header("Location: loginSignup.php?msg=".$returnValue);
	exit();

}



?>