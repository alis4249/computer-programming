<?php 
include 'php/patient.php';

class SignUp extends Connection{

	public function __construct(){
		$this->connect();
	}

	public function signUp($patient){

		$usernameAvailable = false;

		$c = "SELECT id FROM patient WHERE username = ?";
		$sc = $this->conn->prepare($c);
		$sc->bind_param("s",$patient->getUsername());

		if ( $sc->execute() ) {
			$sc->store_result();

			if ( $sc->num_rows == 0 ) {
				$usernameAvailable = true;
			}
		}

		if ( $usernameAvailable ) {
			
			$query = "INSERT INTO `patient`(`firstname`, `lastname`, `age`, `sex`, `address`, `phone`, `username`, `password`) VALUES (?,?,?,?,?,?,?,?)";
			$st = $this->conn->prepare($query);
			$st->bind_param("ssisssss",$a,$b,$c,$d,$e,$f,$g,$h);

			$a = $patient->getFirstName();
			$b = $patient->getLastName();
			$c = $patient->getAge();
			$d = $patient->getSex();
			$e = $patient->getAddress();
			$f = $patient->getPhone();
			$g = $patient->getUsername();
			$h = $patient->getPassword();

			if ( $st->execute() ){
				$rt = "ok";
			}else{
				$rt = "error";
			}

		}else{
			$rt = "usernameTaken";
		}
		return $rt;

	}

}

	
if ( isset($_POST["btnSignup"]) ) {

	$returnValue = "";

	if ( isset($_POST["username"]) && isset($_POST["password"]) &&
		 isset($_POST["firstName"]) && 
		 isset($_POST["lastName"]) && 
		 isset($_POST["age"]) && 
		 isset($_POST["sex"]) && 
		 isset($_POST["phone"]) && 
		 isset($_POST["address"])
		) {

		$firstName = $_POST["firstName"];
		$lastName = $_POST["lastName"];
		$age = $_POST["age"];
		$un = $_POST["username"];
		$ps = $_POST["password"];
		$address = $_POST["address"];
		$phone = $_POST["phone"];
		$sex = $_POST["sex"];

		if ( strlen($firstName) > 0 
			 && strlen($lastName) > 0 
			 && strlen($un) > 0 
			 && strlen($ps) > 0
			 && strlen($phone) > 0
			 && strlen($sex) > 0
			 && strlen($address) > 0
			 && strlen($age) > 0
			) {
			
			if ( 
				 strlen($un) >= 5 && strlen($ps) >= 5
				) {

					$patient = new Patient;

					$patient->setFirstName($firstName);
					$patient->setLastName($lastName);
					$patient->setPhone($phone);
					$patient->setUsername($un);
					$patient->setPassword(md5($ps));
					$patient->setAddress($address);
					$patient->setAge($age);
					$patient->setSex($sex);

					$addMember = new SignUp();
					$returnValue = $addMember->signUp($patient);

					if ( $returnValue == "ok" ) {
						$returnValue = "Registration successful.";
					}
					if ( $returnValue == "error" ) {
						$returnValue = "Registration error.";
					}
					if ( $returnValue == "usernameTaken" ) {
						$returnValue = "Username already taken.";
					}

			}else{
				$returnValue = "Username and password is too small!";
			}

		}else{
			$returnValue = "Please enter all the fields.";
		}

	}else{
		$returnValue = "No Post values.";
	}

	header("Location: loginSignup.php?msg=".$returnValue."#signup");
	exit();

}

?>