<?php 
include 'connection.php';
class Appointment extends Connection{

	public function __construct(){
		$this->connect();
	}

	public function book($datetime,$reason,$doctorid){
		$rt = "";
		$query = "INSERT INTO `appointment`( `datetime`, `reason`, `doctorid`, `patientid`) VALUES (?,?,?,?)";
		$st = $this->conn->prepare($query);
		$st->bind_param("ssii",$a,$b,$c,$d);

		$a = $datetime;
		$b = $reason;
		$c = $doctorid;
		$d = $_SESSION["userid"];

		if ( $st->execute() ){
			$rt = "ok";
		}else{
			$rt = "error";
		}
		return $rt;

	}

}
?>