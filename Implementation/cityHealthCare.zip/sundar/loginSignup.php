<?php 
include 'session.php';

if ( $loggedIn ) {
	header("Location: index.php?msg=You are already logged in");
	exit();
}
include 'php/classes/connection.php';
include 'php/classes/login.php';
include 'php/classes/signup.php';

?>

<!DOCTYPE html>
<html>
<head>
	<?php 
	$title = "Login / Sign Up";
	include 'head.php';
	?>
</head>
<body>

	<div class="login-page">
		<a href="index.php" class="btn">Home</a>
	  <div class="form">
	    <form class="register-form" action="loginSignup.php" method="POST">
			<h4>Sign Up</h4>
			<small>Patient Sing Up</small>
			<input type="text" name="username" placeholder="username"/>
			<input type="password" name="password" placeholder="password"/>
			<input type="text" name="firstName" placeholder="firstname"/>
			<input type="text" name="lastName" placeholder="lastname"/>
			<input type="number" name="age" placeholder="age"/>
			<select name="sex">
				<option value="male">Male</option>
				<option value="female">Female</option>
			</select>
			<input type="text" name="phone" placeholder="phone"/>
			<input type="text" name="address" placeholder="address"/>
			<button name="btnSignup">create</button>
			<p class="message">Already registered? <a href="#">Sign In</a></p>
	    </form>
	    <form class="login-form" action="loginSignup.php" method="POST">
			<h4>Login</h4>
			<small>Patient Login</small>
			<input type="text" name="username" placeholder="username"/>
			<input type="password" name="password" placeholder="password"/>
			<button name="btnLogin" type="submit">login</button>
			<p class="message">Not registered? <a href="#">Create an account</a></p>
	    </form>
	  </div>
	</div>

	<script type="text/javascript">
		$('.message a').click(function(){
		   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
		});

		if ( window.location.hash == "#signup" ) {
		   $('.register-form').toggle();
		   $('.login-form').toggle();
		}


	</script>

</body>
</html>